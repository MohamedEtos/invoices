$( document ).ready(function() {
    alert( "ready!" );
});